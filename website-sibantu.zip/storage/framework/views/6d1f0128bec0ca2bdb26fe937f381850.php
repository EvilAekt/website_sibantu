<?php $__env->startSection('title', 'Data Bantuan'); ?>

<?php $__env->startSection('content'); ?>

<div class="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
    <div>
        <h1 class="text-3xl font-bold text-gray-800 dark:text-white">Stok Bantuan</h1>
        <p class="text-gray-500 dark:text-gray-400 text-sm">Kelola ketersediaan logistik bantuan.</p>
    </div>
    <button class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg shadow-md transition flex items-center gap-2 transform hover:scale-105">
        <i class="fas fa-plus"></i> Tambah Stok
    </button>
</div>


<div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
    <div class="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md border-l-4 border-blue-500">
        <div class="text-gray-500 text-sm">Total Jenis Bantuan</div>
        <div class="text-2xl font-bold text-gray-800 dark:text-white mt-1"><?php echo e($dataBantuan->count()); ?> Jenis</div>
    </div>
    <div class="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md border-l-4 border-green-500">
        <div class="text-gray-500 text-sm">Stok Aman (>100)</div>
        <div class="text-2xl font-bold text-gray-800 dark:text-white mt-1"><?php echo e($dataBantuan->where('stok', '>', 100)->count()); ?> Item</div>
    </div>
    <div class="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md border-l-4 border-red-500">
        <div class="text-gray-500 text-sm">Stok Menipis (<50)</div>
        <div class="text-2xl font-bold text-gray-800 dark:text-white mt-1"><?php echo e($dataBantuan->where('stok', '<', 50)->count()); ?> Item</div>
    </div>
</div>


<div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden border border-gray-100 dark:border-gray-700">
    <div class="overflow-x-auto">
        <table class="w-full text-left">
            <thead class="bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-200 uppercase text-xs font-bold tracking-wider">
                <tr>
                    <th class="px-6 py-4">Nama Bantuan</th>
                    <th class="px-6 py-4">Kategori</th>
                    <th class="px-6 py-4">Stok</th>
                    <th class="px-6 py-4">Keterangan</th>
                    <th class="px-6 py-4 text-center">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                <?php $__empty_1 = true; $__currentLoopData = $dataBantuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-blue-50 dark:hover:bg-gray-700/50 transition duration-150">
                    <td class="px-6 py-4 font-bold text-gray-800 dark:text-white">
                        <?php echo e($item->nama_bantuan); ?>

                    </td>
                    <td class="px-6 py-4">
                        <span class="px-2.5 py-1 rounded-full text-xs font-bold uppercase bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200 border border-blue-200 dark:border-blue-800">
                            <?php echo e($item->kategori); ?>

                        </span>
                    </td>
                    <td class="px-6 py-4">
                        <?php if($item->stok < 50): ?>
                            <span class="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200 px-3 py-1 rounded-full text-xs font-bold animate-pulse">
                                <?php echo e($item->stok); ?>

                            </span>
                        <?php else: ?>
                            <span class="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200 px-3 py-1 rounded-full text-xs font-bold">
                                <?php echo e($item->stok); ?>

                            </span>
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">
                        <?php echo e(Str::limit($item->keterangan, 40) ?? '-'); ?>

                    </td>
                    <td class="px-6 py-4 text-center">
                        <div class="flex justify-center gap-2">
                            <button class="p-2 bg-yellow-100 text-yellow-600 rounded-lg hover:bg-yellow-200 transition"><i class="fas fa-edit"></i></button>
                            <button class="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition"><i class="fas fa-trash"></i></button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="px-6 py-10 text-center text-gray-500 dark:text-gray-400">
                        <div class="flex flex-col items-center">
                            <i class="fas fa-box-open text-4xl mb-2 opacity-50"></i>
                            <p>Belum ada data bantuan.</p>
                        </div>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\pepepkkk\website-sibantu\resources\views/admin/bantuan.blade.php ENDPATH**/ ?>