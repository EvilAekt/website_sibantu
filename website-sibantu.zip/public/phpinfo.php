<?php
// Temporary phpinfo for debugging PDO extensions
phpinfo();
