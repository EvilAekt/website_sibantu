<?php $__env->startSection('title', 'Pengaturan Profil - SiBantu'); ?>

<?php $__env->startSection('header'); ?>
    <div class="flex flex-col">
        <h1 class="text-xl font-bold text-gray-800 dark:text-white">Pengaturan Akun</h1>
        <p class="text-xs text-gray-500">Kelola informasi profil dan keamanan akun Anda</p>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="space-y-6">
        <div
            class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow-sm sm:rounded-xl border border-gray-100 dark:border-gray-700">
            <div class="max-w-xl">
                <?php echo $__env->make('profile.partials.update-profile-information-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        <div
            class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow-sm sm:rounded-xl border border-gray-100 dark:border-gray-700">
            <div class="max-w-xl">
                <?php echo $__env->make('profile.partials.update-password-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        <div
            class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow-sm sm:rounded-xl border border-gray-100 dark:border-gray-700">
            <div class="max-w-xl">
                <?php echo $__env->make('profile.partials.delete-user-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Python\website_sibantu\resources\views/profile/edit.blade.php ENDPATH**/ ?>