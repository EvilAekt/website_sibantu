

<?php $__env->startSection('title', 'Syarat & Ketentuan - SiBantu'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-4xl mx-auto px-4 py-12">
        <h1 class="text-3xl font-bold mb-6">Syarat & Ketentuan</h1>
        <div class="prose dark:prose-invert max-w-none">
            <p>Selamat datang di SiBantu. Dengan menggunakan platform ini, Anda menyetujui syarat dan ketentuan berikut:</p>

            <h3>1. Penggunaan Platform</h3>
            <p>Platform ini bertujuan untuk memfasilitasi pelaporan bencana dan penyaluran bantuan. Pengguna dilarang
                menyalahgunakan platform untuk tujuan penipuan atau penyebaran informasi palsu (hoax).</p>

            <h3>2. Pelaporan Bencana</h3>
            <p>Setiap laporan yang masuk akan diverifikasi oleh tim internal kami. Pelapor wajib menyertakan bukti foto yang
                valid dan lokasi yang akurat.</p>

            <h3>3. Donasi</h3>
            <p>Donasi yang terkumpul akan disalurkan kepada penerima manfaat sesuai dengan kampanye yang dipilih. SiBantu
                berhak memotong biaya operasional sebesar 5% dari total donasi.</p>

            <h3>4. Penarikan Dana</h3>
            <p>Fundraiser hanya dapat menarik dana setelah kampanye diverifikasi dan memenuhi syarat pencairan.</p>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Python\website_sibantu\resources\views/pages/terms.blade.php ENDPATH**/ ?>