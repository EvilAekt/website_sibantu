<svg class="h-9 w-auto fill-current text-blue-700" viewBox="0 0 24 24">
    <path d="M12 2L2 7v10c0 5.55 3.84 9.74 9 11 5.16-1.26 9-5.45 9-11V7l-10-5z"/>
    <circle cx="12" cy="10" r="3"/>
</svg>